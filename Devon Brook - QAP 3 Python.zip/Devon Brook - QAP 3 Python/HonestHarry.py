# Desc: Program for Honest Harry to keep track of his car sales.
# Author: Devon Brook (SD 16)
# Dates: Nov 10, 2025 - Nov 24, 2025


# Define required libraries.
import datetime as dt
import FormatValues as FV


# Define program constants.
INV_DATE = dt.datetime.now()
HST_RATE = 0.15


# Define program functions.
def CalcLicenseFee(SellPrice):

    if SellPrice <= 15000.00:
        LicenseFee = 75.00
    else:
        LicenseFee = 165.00

    return LicenseFee

def CalcTransferFee(SellPrice):

    TransferFee = 0.01 * SellPrice

    if SellPrice > 20000.00:
        TransferFee += (0.016 * SellPrice)
    else:
        TransferFee = TransferFee

    return TransferFee

def CalcTotSalePrice(PriceAftTrade, LicenseFee, TransferFee):

    Subtotal = PriceAftTrade + LicenseFee + TransferFee
    HSTCost = HST_RATE * Subtotal
    TotSalePrice = Subtotal + HSTCost

    return Subtotal, HSTCost, TotSalePrice


# Main program starts here.
while True:
    print()
    FirstName =   input("Enter the customer's first name (END to quit):     ").title()
    if FirstName == "End":
        break

    # Gather user inputs.
    while True:
        if FirstName == "":
            print(f"  ** Data Entry Error - First name cannot be blank.")
        else:
            break
    
    while True:
        LastName =    input("Enter the customer's last name:                    ").title()

        if LastName == "":
            print(f"  ** Data Entry Error - Last name cannot be blank.")
        else:
            break
    
    while True:
        Phone =       input("Enter the phone number (9999999999):               ")

        if Phone == "":
            print(f"  ** Data Entry Error - Phone number cannot be blank.")
        elif len(Phone) != 10:
            print(f"  ** Data Entry Error - Phone number must be 10 characters.")
        elif Phone.isdigit() == False:
            print(f"  ** Data Entry Error - Phone number must be 10 digits.")
        else:
            # Format the value before breaking out of the loop.
            Phone = "(" + Phone[0:3] + ") " + Phone[3:6] + "-" + Phone[6:10]
            break
    
    while True:
        PlateNum =    input("Enter the plate number (XXX999):                   ").upper()

        if PlateNum == "":
            print(f"  ** Data Entry Error - Plate number cannot be blank.")
        elif len(PlateNum) != 6:
            print(f"  ** Data Entry Error - Plate number must be 6 characters.")
        else:
            break
    
    CarMake =         input("Enter the car make (ie: Toyota):                   ").title()
    CarModel =        input("Enter the car model (ie: Corolla):                 ").title()
    CarYear =         input("Enter the car year (ie: 2018):                     ")

    while True:
        SellPrice =   input("Enter the selling price:                           ")
        SellPrice = float(SellPrice)

        if SellPrice > 50000.00:
            print(f"  ** Data Entry Error - Selling price cannot exceed $50,000.00.")
        else:
            break
    
    while True:
        TradeInAmt =  input("Enter the amount of the trade in:                  ")
        TradeInAmt = float(TradeInAmt)

        if TradeInAmt > SellPrice:
            print(f"  ** Data Entry Error - Trade in amount cannot exceed the selling price.")
        else:
            break

    while True:
        Salesperson = input("Enter the salespersons name:                       ").title()

        if Salesperson == "":
            print(f"  ** Data Entry Error - Salespersons name cannot be blank.")
        else:
            break
    
    FirstInitial = FirstName[:1]
    LastInitial = LastName[:1]
    LicenseHalf = PlateNum[-3:]
    PhoneSect = Phone[-4:]

    # Perform required calculations.

    PriceAftTrade = SellPrice - TradeInAmt

    if SellPrice <= 15000.00:
        LicenseFee = 75.00
    else:
        LicenseFee = 165.00

    TransferFee = 0.01 * SellPrice

    if SellPrice > 20000.00:
        TransferFee += (0.016 * SellPrice)
    else:
        TransferFee = TransferFee

    Subtotal = PriceAftTrade + LicenseFee + TransferFee
    HSTCost = HST_RATE * Subtotal
    TotSalePrice = Subtotal + HSTCost

    # Payment schedule calculations.

    # 1 year.
    NumMonPay1 = 1 * 12
    FinanceFee1 = 1 * 39.99
    TotalPrice1 = TotSalePrice + FinanceFee1
    MonPay1 = TotalPrice1 / 12

    # 2 years.
    NumMonPay2 = 2 * 12
    FinanceFee2 = 2 * 39.99
    TotalPrice2 = TotSalePrice + FinanceFee2
    MonPay2 = TotalPrice2 / 12

    # 3 years.
    NumMonPay3 = 3 * 12
    FinanceFee3 = 3 * 39.99
    TotalPrice3 = TotSalePrice + FinanceFee3
    MonPay3 = TotalPrice3 / 12

    # 4 years.
    NumMonPay4 = 4 * 12
    FinanceFee4 = 4 * 39.99
    TotalPrice4 = TotSalePrice + FinanceFee4
    MonPay4 = TotalPrice4 / 12

    # First payment date.
    FirstPayDate = INV_DATE
    FirstPayDate = INV_DATE.replace(day=1)

    PayYear = FirstPayDate.year
    PayMonth = FirstPayDate.month
    PayDay = FirstPayDate.day

    if INV_DATE.day > 24:
        FirstPayDate = dt.datetime(PayYear + 1, PayMonth - 10, PayDay)
    else:
        FirstPayDate = dt.datetime(PayYear, PayMonth + 1, PayDay)

    # Display program results.

    print()
    print(f"Honest Harry Car Sales                                    Invoice Date:   {FV.FDateL(INV_DATE):>5s}")
    print(f"Used Car Sale and Receipt                                 Receipt No:      {FirstInitial}{LastInitial}-{LicenseHalf}-{PhoneSect}")
    print()
    print(f"                                                    Sale price:        {FV.FDollar2(SellPrice):>15s}")
    print(f"Sold to:                                            Trade Allowance:   {FV.FDollar2(TradeInAmt):>15s}")
    print(f"                                                    ----------------------------------")
    print(f"     {FirstInitial}. {LastName:<28s}                Price after Trade: {FV.FDollar2(PriceAftTrade):>15s}")
    print(f"     {Phone:<10s}                                 License Fee:       {FV.FDollar2(LicenseFee):>15s}")
    print(f"                                                    Transfer Fee:      {FV.FDollar2(TransferFee):>15s}")
    print(f"                                                    ----------------------------------")
    print(f"Car Details:                                        Subtotal:          {FV.FDollar2(Subtotal):>15s}")
    print(f"                                                    HST:               {FV.FDollar2(HSTCost):>15s}")
    print(f"     {CarYear} {CarMake} {CarModel:<23s}            ----------------------------------")
    print(f"                                                    Total sales price: {FV.FDollar2(TotSalePrice):>15s}")
    print()
    print(f"--------------------------------------------------------------------------------------")
    print()
    print(f"                                    Financing            Total            Monthly")
    print(f"     # Years     # Payments            Fee               Price            Payment")
    print(f"     ----------------------------------------------------------------------------")
    print(f"        1            12            {FV.FDollar2(FinanceFee1):>9s}           {FV.FDollar2(TotalPrice1):>2s}       {FV.FDollar2(MonPay1):>9s}")
    print(f"        2            24            {FV.FDollar2(FinanceFee2):>9s}           {FV.FDollar2(TotalPrice2):>2s}       {FV.FDollar2(MonPay2):>9s}")
    print(f"        3            36            {FV.FDollar2(FinanceFee3):>9s}           {FV.FDollar2(TotalPrice3):>2s}       {FV.FDollar2(MonPay3):>9s}")
    print(f"        4            48            {FV.FDollar2(FinanceFee4):>9s}           {FV.FDollar2(TotalPrice4):>2s}       {FV.FDollar2(MonPay4):>9s}")
    print(f"     ----------------------------------------------------------------------------")
    print(f"     First payment date: {FV.FDateM(FirstPayDate)}")
    print(f"--------------------------------------------------------------------------------------")
    print(f"                        Best used cars at the best prices!")
    print()
