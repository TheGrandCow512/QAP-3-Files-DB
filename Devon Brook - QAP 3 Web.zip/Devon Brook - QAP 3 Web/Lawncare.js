// Desc: Program for Mo's Lawncare Services to enter the appropriate information and prepare a customer invoice for their clients.
// Author: Devon Brook (SD 16)
// Dates: Nov 10, 2025 - Nov 24, 2025

var $ = function (id) {
  return document.getElementById(id);
};

// Define format options for printing.
const cur2Format = new Intl.NumberFormat("en-CA", {
  style: "currency",
  currency: "CAD",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const per2Format = new Intl.NumberFormat("en-CA", {
  style: "percent",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

const com2Format = new Intl.NumberFormat("en-CA", {
  style: "decimal",
  minimumFractionDigits: "2",
  maximumFractionDigits: "2",
});

// Define program constants.
const BORDER_PERCENT = 0.04;
const BORDER_RATE = 0.28;
const LAWN_PERCENT = 0.95;
const LAWN_RATE = 0.04;
const FERT_RATE = 0.03;

const HST_RATE = 0.15;
const ENV_TAX_RATE = 0.014;

// Gather user input.
let CustName = prompt("Enter the customer name: ");
let StAdd = prompt("Enter the street address: ");
let City = prompt("Enter the city: ");
let Phone = prompt("Enter the phone number (999-999-9999): ");
let SqFeet = prompt(
  "Enter the total number of square feet for the property (#####): "
);
SqFeet = parseFloat(SqFeet);

// Calculate program results.
let BorderCost = BORDER_PERCENT * SqFeet * BORDER_RATE;
let MowingCost = LAWN_PERCENT * SqFeet * LAWN_RATE;
let FertCost = FERT_RATE * SqFeet;

let TotCharges = BorderCost + MowingCost + FertCost;

let SalesTax = HST_RATE * TotCharges;
let EnvTax = ENV_TAX_RATE * TotCharges;

let InvTotal = TotCharges + SalesTax + EnvTax;

// Display the results using a table.
document.writeln("<br /><br />");
document.writeln("<table class='invtable'>");

document.writeln("<tr>");
document.writeln(
  "<td colspan='2' class='orangeback'><br />Mo's Lawncare Services - Customer Invoice<br /><br /></td>"
);
document.writeln("</tr>");

document.writeln("<tr class='whiteback'>");
document.writeln("<td colspan='2'><br />Customer details:<br /><br />");
document.writeln("Customer name: " + CustName + "<br />");
document.writeln("Address: " + StAdd + "<br />");

document.writeln(City + ", " + Phone + "<br /><br />");

document.writeln("Property size (in sq feet): " + SqFeet + "<br /><br />");

document.writeln("</td>");

document.writeln("<tr>");
document.writeln("<td>Border cost:</td>");
document.writeln(
  "<td class='righttext'>" + cur2Format.format(BorderCost) + "</td>"
);
document.writeln("<tr>");

document.writeln("<tr>");
document.writeln("<td>Mowing cost:</td>");
document.writeln(
  "<td class='righttext'>" + cur2Format.format(MowingCost) + "</td>"
);
document.writeln("<tr>");

document.writeln("<tr>");
document.writeln("<td>Fertilizer cost:</td>");
document.writeln(
  "<td class='righttext'>" + cur2Format.format(FertCost) + "</td>"
);
document.writeln("<tr>");

document.writeln("<tr>");
document.writeln("<td><br /></td>");
document.writeln("<td class='righttext'>" + "<br />" + "</td>");
document.writeln("<tr>");

document.writeln("<tr>");
document.writeln("<td>Total charges:</td>");
document.writeln(
  "<td class='righttext'>" + cur2Format.format(TotCharges) + "</td>"
);
document.writeln("<tr>");

document.writeln("<tr>");
document.writeln("<td><br /></td>");
document.writeln("<td class='righttext'>" + "<br />" + "</td>");
document.writeln("<tr>");

document.writeln("<tr>");
document.writeln("<td>Sales tax (HST):</td>");
document.writeln(
  "<td class='righttext'>" + cur2Format.format(SalesTax) + "</td>"
);
document.writeln("<tr>");

document.writeln("<tr>");
document.writeln("<td>Environmental tax:</td>");
document.writeln(
  "<td class='righttext'>" + cur2Format.format(EnvTax) + "</td>"
);
document.writeln("<tr>");

document.writeln("<tr>");
document.writeln("<td><br /></td>");
document.writeln("<td class='righttext'>" + "<br />" + "</td>");
document.writeln("<tr>");

document.writeln("<tr>");
document.writeln("<td>Invoice total:</td>");
document.writeln(
  "<td class='righttext'>" + cur2Format.format(InvTotal) + "</td>"
);
document.writeln("<tr>");

document.writeln("<tr>");
document.writeln(
  "<td colspan='2' class='orangeback'><br />Turning Lawns into Landscapes<br /><br /></td>"
);
document.writeln("</tr>");

document.writeln("</table><br /><br />");
